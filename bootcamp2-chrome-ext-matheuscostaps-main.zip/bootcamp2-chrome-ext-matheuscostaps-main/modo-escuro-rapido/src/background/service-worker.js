// Este código simples garante que o service worker seja ativado
// quando a extensão é instalada.
chrome.runtime.onInstalled.addListener(() => {
    console.log('Service Worker da extensão está ativo!');
  });