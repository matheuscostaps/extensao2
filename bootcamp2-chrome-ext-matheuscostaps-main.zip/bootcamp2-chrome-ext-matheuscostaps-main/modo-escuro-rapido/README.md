# Modo Escuro Rápido

Uma extensão simples para Google Chrome que ativa/desativa rapidamente o modo escuro em qualquer site.

## Instalação
1. Abra o Chrome e vá em `chrome://extensions/`
2. Ative **Modo de desenvolvedor**
3. Clique em **Carregar sem compactação**
4. Selecione a pasta `modo-escuro-rapido`

## Como usar
1. Abra qualquer site
2. Clique no ícone da extensão
3. Clique em **Ativar/Desativar**
