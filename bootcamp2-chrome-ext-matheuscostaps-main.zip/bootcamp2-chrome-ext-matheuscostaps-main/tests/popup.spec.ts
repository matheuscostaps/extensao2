import { test, expect, type Page } from '@playwright/test';

async function getExtensionId(page: Page): Promise<string> {
  // Espera pelo evento do service worker para garantir que a extensão carregou
  const serviceWorker = await page.context().waitForEvent('serviceworker');
  const url = serviceWorker.url();
  // Extrai o ID da extensão da URL do service worker
  const extensionId = new URL(url).hostname;
  return extensionId;
}

test.describe('Validação do Popup da Extensão "Modo Escuro Rápido"', () => {

  // Antes de cada teste, executa este bloco para preparar o ambiente
  test.beforeEach(async ({ page }) => {
    const extensionId = await getExtensionId(page);
    const popupUrl = `chrome-extension://${extensionId}/src/popup/popup.html`;
    await page.goto(popupUrl);
  });

  test('deve exibir o título principal corretamente', async ({ page }) => {
    const titulo = page.locator('h1');
    await expect(titulo).toBeVisible();
    await expect(titulo).toHaveText('Modo Escuro Rápido');
  });

  test('deve exibir o subtítulo da extensão', async ({ page }) => {
    const subtitulo = page.locator('p.subtitle');
    await expect(subtitulo).toBeVisible();
    await expect(subtitulo).toContainText('Uma experiência de navegação mais confortável');
  });

  test('deve ter um botão de download visível', async ({ page }) => {
    const botaoDownload = page.getByRole('link', { name: 'Baixar Extensão' });
    await expect(botaoDownload).toBeVisible();
  });

  test('deve listar a feature "Ativação Instantânea"', async ({ page }) => {
    const feature = page.locator('li:has-text("Ativação Instantânea")');
    await expect(feature).toBeVisible();
  });
});